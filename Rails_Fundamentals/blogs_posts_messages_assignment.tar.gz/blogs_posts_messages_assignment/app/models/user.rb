class User < ActiveRecord::Base
  has_many :owners
  has_many :messages, through: :messengers
  has_many :posts, through: :posters
end
