require 'rails_helper'

RSpec.describe WallController, type: :controller do
end
